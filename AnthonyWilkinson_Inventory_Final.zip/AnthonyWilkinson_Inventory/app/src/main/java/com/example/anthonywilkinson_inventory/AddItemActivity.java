package com.example.anthonywilkinson_inventory;

import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.anthonywilkinson_inventory.database.AppDatabase;

public class AddItemActivity extends AppCompatActivity {

    private EditText itemField;
    private EditText quantityField;

    private AppDatabase db;

    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        itemField = findViewById(R.id.item_name_edit_text);
        quantityField = findViewById(R.id.quantity_edit_text);

        db = new AppDatabase(this);

        toolbar = findViewById(R.id.edit_toolbar);
        setSupportActionBar(toolbar);
        // Enable back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void addToDatabase(View view) {
        String itemName = itemField.getText().toString().trim(); // getText returns an object
        String quantityText = quantityField.getText().toString().trim();
        // Convert String to Int
        int quantity = Integer.parseInt(quantityText);
        if (!db.itemExists(itemName)){
            db.addItem(itemName, quantity);
            Toast.makeText(this,"Item added", Toast.LENGTH_LONG).show();
            if (quantity == 0) {
                sendLowStockSMS(itemName);
            }
        }
        else {
            Toast.makeText(this, "Item already exists", Toast.LENGTH_LONG).show();
        }
    }
    private void sendLowStockSMS(String itemName) {
        // Check permission first
        if (androidx.core.content.ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return; // Permission not granted, do nothing
        }

        String phoneNumber = "9491234567";
        String message = "Inventory Alert: " + itemName + " is out of stock.";
        Toast.makeText(this, "SMS would be sent to " + phoneNumber + " for: " +
                itemName, Toast.LENGTH_LONG).show();
        android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    // Return to Inventory Screen when back buton is pushed
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}