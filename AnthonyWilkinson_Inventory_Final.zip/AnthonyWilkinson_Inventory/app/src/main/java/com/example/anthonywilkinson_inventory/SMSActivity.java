package com.example.anthonywilkinson_inventory;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private Button button;

    private TextView smsStatus;
    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Toolbar toolbar = findViewById(R.id.settings_toolbar);
        setSupportActionBar(toolbar);
        // Enable back button in toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        smsStatus = findViewById(R.id.sms_status);
        button = findViewById(R.id.change_sms_status);
        updateText();
    }

    private void updateText() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            smsStatus.setText("SMS Access Enabled");
            button.setEnabled(false); // Disable button since SMS permission is already granted
        } else {
            smsStatus.setText("SMS Access Disabled");
        }
    }

    // Request permission to send text messages
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE
        );
    }

    // Update screen if permission is granted
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
           updateText();
        }
    }


    public void toggleSMS(View view){ // XML onClick needs a method with a View parameter
        requestSmsPermission();
    }

    // Return to Inventory Screen when back button is pushed
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
