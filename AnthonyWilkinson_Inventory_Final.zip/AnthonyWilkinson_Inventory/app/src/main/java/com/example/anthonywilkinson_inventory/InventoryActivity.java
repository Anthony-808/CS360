package com.example.anthonywilkinson_inventory;

import android.content.Intent;
import android.content.pm.PackageManager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import androidx.recyclerview.widget.RecyclerView;

import com.example.anthonywilkinson_inventory.database.AppDatabase;
import com.example.anthonywilkinson_inventory.model.Row;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private AppDatabase db;
    private ItemAdapter adapter;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        db = new AppDatabase(this);

        recyclerView = findViewById(R.id.item_list);

        adapter = new ItemAdapter(db.getAllInventory());
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.add_item_button);
        fab.setOnClickListener(v -> {
            // Go to AddItem screen
            Intent intent = new Intent(this, AddItemActivity.class);
            startActivity(intent);
        });
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder> {

        private List<Row> rows;

        public ItemAdapter(List<Row> rows) {
            this.rows = rows;
        }

        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {

            Row row = rows.get(position);
            holder.itemTextView.setText(row.getItem());
            holder.quantityTextView.setText(String.valueOf(row.getQuantity()));

            holder.addButton.setOnClickListener(v -> {
                // Increase value of item in database by quantity
                db.updateQuantity(row.getItem(), 1);
                // Change value in view
                row.setQuantity(row.getQuantity() + 1);
                // Make change visible
                notifyItemChanged(position);

            });

            holder.subtractButton.setOnClickListener(v -> {
                if (row.getQuantity() > 0) {
                    db.updateQuantity(row.getItem(), -1);
                    row.setQuantity(row.getQuantity() - 1);
                    notifyItemChanged(position);
                    if (row.getQuantity() == 0) {
                        sendLowStockSMS(row.getItem());
                    }
                }

            });

            holder.deleteButton.setOnClickListener(v -> {
                db.deleteItem(row.getItem());
                rows.remove(position);
                notifyItemRemoved(position);
            });

        }
        @Override
        public int getItemCount() {
            return rows.size();
        }
    }

    private static class ItemHolder extends RecyclerView.ViewHolder {
        private final TextView itemTextView;
        private final TextView quantityTextView;

        private final Button addButton;
        private final Button subtractButton;
        private final ImageButton deleteButton;
        public ItemHolder (LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item, parent, false));
            itemTextView = itemView.findViewById(R.id.item_textview);
            quantityTextView = itemView.findViewById(R.id.quantity_textview);
            addButton = itemView.findViewById(R.id.add_button);
            subtractButton = itemView.findViewById(R.id.subtract_button);
            deleteButton = itemView.findViewById(R.id.imageButton);
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.inventory_menu, menu);
        return true;
    }

    // Go to SMS screen when settings button is selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_settings) {
            Intent intent = new Intent(this, SMSActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void sendLowStockSMS(String itemName) {
        // Check permission
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission not granted, don't send SMS
            return;
        }

        String phoneNumber = "9491234567";
        String message = "Inventory Alert: " + itemName + " is out of stock.";
        Toast.makeText(this, "SMS would be sent to " + phoneNumber + " for: " +
                itemName, Toast.LENGTH_LONG).show();
        android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    // Refresh view when returning to screen from AddItem
    @Override
    protected void onResume() {
        super.onResume();
        adapter.rows = db.getAllInventory();
        adapter.notifyDataSetChanged();
    }
}