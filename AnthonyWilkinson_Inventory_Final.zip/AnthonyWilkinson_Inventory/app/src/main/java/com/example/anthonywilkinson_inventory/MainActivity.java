package com.example.anthonywilkinson_inventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import com.example.anthonywilkinson_inventory.database.AppDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;

    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usernameField = findViewById(R.id.username_edit_text);
        passwordField = findViewById(R.id.password_edit_text);
        db = new AppDatabase(this);
    }

    public void login(View view) {
        String username = usernameField.getText().toString().trim(); // getText returns an object
        String password = passwordField.getText().toString().trim();
        if (db.userExists(username, password)) {
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, InventoryActivity.class);
            startActivity(intent);
            finish();
        }
        else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }

    public void register(View view) {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        if (db.userExists(username, password)) {
            Toast.makeText(this, "user already exists", Toast.LENGTH_SHORT).show();
        }
        else {
            if (db.addUser(username, password) != -1) {
                Toast.makeText(this, "Account registered", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        }
    }
}