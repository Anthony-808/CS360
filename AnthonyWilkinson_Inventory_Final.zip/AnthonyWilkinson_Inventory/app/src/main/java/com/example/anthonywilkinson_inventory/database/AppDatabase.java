package com.example.anthonywilkinson_inventory.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.anthonywilkinson_inventory.model.Row;

import java.util.ArrayList;
import java.util.List;

public class AppDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "app_database.db";
    private static final int VERSION = 1; // Facilitates database updates and synchronization

    public AppDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password);

        return db.insert(LoginTable.TABLE, null, values);

    }

    public boolean userExists(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT _id FROM " + LoginTable.TABLE + " WHERE username = ? AND password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password});
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_QUANTITY = "quantity";
    }

    public long addItem(String item, int quantity){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues(); // Increase clarity and security of insert commands
        values.put(InventoryTable.COL_ITEM, item);
        values.put(InventoryTable.COL_QUANTITY, quantity);

        return db.insert(InventoryTable.TABLE, null, values);
    }

    public boolean itemExists(String item) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT " + InventoryTable.COL_ID + " FROM " +
                InventoryTable.TABLE + " WHERE item = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { item});
        boolean exists = cursor.moveToFirst(); // Returns false if item isn't found
        cursor.close();
        return exists;
    }

    // Increase quantity of 'item' by 'quantity'
    public void updateQuantity(String item, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (itemExists(item)) {
            String sql = "UPDATE " + InventoryTable.TABLE +
                    " SET " + InventoryTable.COL_QUANTITY +
                    " = "  + InventoryTable.COL_QUANTITY + " + ? " +
                    "WHERE " + InventoryTable.COL_ITEM + " = ?";
            db.execSQL(sql, new Object[] {quantity, item});
        }
    }

    public void deleteItem(String item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(InventoryTable.TABLE, InventoryTable.COL_ITEM + " = ?",
                new String[]{item});
    }

    public List<Row> getAllInventory() {
        List<Row> rows = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryTable.TABLE, null);
        // Get colum indices
        int idIndex = cursor.getColumnIndex(InventoryTable.COL_ID);
        int itemIndex = cursor.getColumnIndex(InventoryTable.COL_ITEM);
        int quantityIndex = cursor.getColumnIndex(InventoryTable.COL_QUANTITY);
        // Assign values of row in database to row object, add to list.
        while (cursor.moveToNext()){
            rows.add(new Row(cursor.getInt(idIndex),
                    cursor.getString(itemIndex),
                    cursor.getInt(quantityIndex)));
        }
        cursor.close();
        return rows;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text)");

        db.execSQL("create table " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " text, " +
                InventoryTable.COL_QUANTITY + " integer)");
    }

    // Refresh database when version is changed
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

}
