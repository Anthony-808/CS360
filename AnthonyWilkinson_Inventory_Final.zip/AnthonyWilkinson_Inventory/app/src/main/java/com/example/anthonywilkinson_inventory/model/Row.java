package com.example.anthonywilkinson_inventory.model;

public class Row {
    private int id;
    private String item;
    private int quantity;

    public Row(int id, String item, int quantity) {
        this.id = id;
        this.item = item;
        this.quantity = quantity;
    }

    // getters
    public int getId() {return id;}
    public String getItem() {return item;}
    public int getQuantity() {return quantity;}
    // setter
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
